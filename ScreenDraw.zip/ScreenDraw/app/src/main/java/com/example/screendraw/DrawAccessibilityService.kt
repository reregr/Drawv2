package com.example.screendraw

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Sadece çizim katmanını "güvenilir" pencere yapmak için kullanılır; ekran içeriğini okumaz. */
class DrawAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: DrawAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
